import { createContext } from "react"

const CurrentUserContext = createContext(undefined);

export default CurrentUserContext;