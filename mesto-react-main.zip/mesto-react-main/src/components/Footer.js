const Footer = () => {
  return (
    <footer className="page__footer footer">
      <p className="footer__text">&copy; 2022 Mesto Russia</p>
    </footer>
  );
};

export default Footer;
